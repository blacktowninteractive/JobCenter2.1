/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package multiplescreenframework;

/**
 *
 * @author angelacaicedo
 */
public interface ScreenController {
    
    //This method will allow the injection of the ScreenPane
    public void setScreenPane(ScreenPane screenPage);
}
