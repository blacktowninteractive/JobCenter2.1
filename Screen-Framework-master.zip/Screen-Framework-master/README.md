Screen-Framework
================

JavaFX Framework for managing multiple application screens